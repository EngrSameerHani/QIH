import React from 'react'

const page = () => {
  return (
    <div>earthquake-2005</div>
  )
}

export default page