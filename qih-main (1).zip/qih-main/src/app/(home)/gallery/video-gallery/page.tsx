import React from 'react'

const page = () => {
  return (
    <div>video-gallery</div>
  )
}

export default page