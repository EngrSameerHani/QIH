import MakeAdminAppointment from '@/components/MakeAdminAppointment'
import React from 'react'

const AdminAppointmentCreatePage = () => {
  return <MakeAdminAppointment />
}

export default AdminAppointmentCreatePage
