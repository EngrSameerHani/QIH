import React from 'react'

const AdminUsers = () => {
  return <div>AdminUsers</div>
}

export default AdminUsers
