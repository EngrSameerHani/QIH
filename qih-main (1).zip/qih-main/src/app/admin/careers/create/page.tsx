import CreateCareer from '@/components/CreateCareer'
import React from 'react'

const CreateCareerPage = () => {
  return <CreateCareer />
}

export default CreateCareerPage
