import React from 'react'
import CreateDepartment from '../CreateDepartment'

const CreateDepartmentPage = () => {
  return (
    <div>
      <CreateDepartment />
    </div>
  )
}

export default CreateDepartmentPage
