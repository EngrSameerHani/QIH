import CreateConsultant from '@/components/CreateConsultants'
import React from 'react'

const CreateConsultantPage = async () => {
  return (
    <div>
      <CreateConsultant />
    </div>
  )
}

export default CreateConsultantPage
