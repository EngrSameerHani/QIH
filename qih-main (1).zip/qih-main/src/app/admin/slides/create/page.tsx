import CreateSlide from '@/components/CreateSlide'
import React from 'react'

const CreateSlidePage = () => {
  return (
    <div>
      <CreateSlide />
    </div>
  )
}

export default CreateSlidePage
