import AddPage from '@/components/AddPage'
import React from 'react'

const CreateNewPage = () => {
  return (
    <div>
      <AddPage />
    </div>
  )
}

export default CreateNewPage
